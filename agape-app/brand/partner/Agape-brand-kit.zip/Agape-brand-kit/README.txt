AGAPE BRAND KIT

Wordmark: Evolved Classic (Big Shoulders Display 900, narrow cut, slanted descender cuts).
  - agape-wordmark.svg: the name alone. Use it most of the time.
  - agape-wordmark-with-tagline.svg: with the quiet stacked "to your seat". Use it where people meet Agape for the first time (website header, receipts, shirts, signage).
  - Reversed and one-colour versions are included for dark backgrounds and single-ink printing.

Icon: the "a" with "to your seat" beside it, centred as one unit.
  - agape-icon.svg: rounded tile, for anywhere an app icon is shown.
  - agape-icon-square.svg: square, for app stores and phones (they round the corners themselves).
  - agape-icon-small*.svg: at small sizes (browser tabs, notifications) the tagline becomes three bars.

Colours
  Agape crimson  #B8174F  (on dark backgrounds use #F2588C)
  Ink            #14161B
  Background     #F3F4F7
  Dark background #0E1014

All files are vector paths, so no fonts need installing. No trademark search has been done yet: do one before printing anything at scale.
